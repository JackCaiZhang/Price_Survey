-- 价格字典表更新触发器：更新“update_time”字段值
CREATE TRIGGER update_price_dict
    ON price_dict
    AFTER UPDATE
    AS
BEGIN
    UPDATE price_dict
    SET update_time = GETDATE()
    FROM inserted
    WHERE price_dict.city_id = inserted.city_id
      AND price_dict.sProperty_id = inserted.sProperty_id
      AND price_dict.app_date = inserted.app_date
      AND price_dict.property_type_new = inserted.property_type_new;
END
GO

