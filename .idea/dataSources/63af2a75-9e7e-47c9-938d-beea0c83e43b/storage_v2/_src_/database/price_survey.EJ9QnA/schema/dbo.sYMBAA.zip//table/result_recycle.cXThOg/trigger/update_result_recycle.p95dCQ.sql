CREATE TRIGGER update_result_recycle
    ON result_recycle
    AFTER UPDATE
    AS
BEGIN
    UPDATE result_recycle
    SET update_time = GETDATE()
    FROM inserted
    WHERE result_recycle.city_id = inserted.city_id
      AND result_recycle.project_id = inserted.project_id
      AND result_recycle.property_type = inserted.property_type
      AND result_recycle.person_in_charge = inserted.person_in_charge;
END
GO

